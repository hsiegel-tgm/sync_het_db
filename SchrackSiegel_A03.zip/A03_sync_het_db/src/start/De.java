package start;

import java.util.Date;

public class De {
	public static void bug(String s){
		Date d = new Date();
		//System.out.println(d+": " + s);
	}
}
